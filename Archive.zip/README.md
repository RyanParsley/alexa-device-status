###Completed solution for the blog article "Developing Alexa Skills Locally with Node.js"

part 1: [https://www.bignerdranch.com/blog/developing-alexa-skills-locally-with-nodejs-setting-up-your-local-environment/](https://www.bignerdranch.com/blog/developing-alexa-skills-locally-with-nodejs-setting-up-your-local-environment/)
part 2: [https://www.bignerdranch.com/blog/developing-alexa-skills-locally-with-nodejs-implementing-an-intent-with-alexa-app-and-alexa-app-server/](https://www.bignerdranch.com/blog/developing-alexa-skills-locally-with-nodejs-implementing-an-intent-with-alexa-app-and-alexa-app-server/)

Node is required to run the test suite(the article will guide you on getting set up #add link). 
To run the tests once you have installed node: 

  - npm install
  - npm test

