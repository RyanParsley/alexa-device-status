###Use Alexa to check the status on IOT devices

Node is required to run the test suite(the article will guide you on getting set up #add link). 
To run the tests once you have installed node: 

  - npm install
  - npm test

